import React, { useEffect, useState, useCallback } from "react";
import { 
  View, 
  Text, 
  Button, 
  TextInput, 
  FlatList,
  Alert, 
  ActivityIndicator,
  ScrollView,
  SafeAreaView,
  TouchableOpacity
} from "react-native";
import { Picker } from '@react-native-picker/picker';
import { NavigationContainer, useNavigation } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import AsyncStorage from "@react-native-async-storage/async-storage";

// EXPO SNACK COMPATIBLE FIREBASE INITIALIZATION
const firebase = require('firebase');
require('firebase/auth');
require('firebase/firestore');

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyCIZD5oxS1ivKYHnNM-UG-zr8iUnG5kYSo",
  authDomain: "recipe-keeper-app-a98d7.firebaseapp.com",
  projectId: "recipe-keeper-app-a98d7",
  storageBucket: "recipe-keeper-app-a98d7.appspot.com",
  messagingSenderId: "924879399425",
  appId: "1:924879399425:web:148fca2e3cf6fea6d0ee00",
  measurementId: "G-GB76GYW3DW"
};

// Initialize Firebase
if (!firebase.apps || !firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const auth = firebase.auth();
const db = firebase.firestore();

// Navigation components
const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Login Screen Component
function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Load saved credentials on component mount
  useEffect(() => {
    const loadSavedCredentials = async () => {
      try {
        const savedEmail = await AsyncStorage.getItem('lastEmail');
        const savedPassword = await AsyncStorage.getItem('lastPassword');
        
        if (savedEmail) {
          setEmail(savedEmail);
        }
        if (savedPassword) {
          setPassword(savedPassword);
        }
      } catch (error) {
        console.log('Error loading saved credentials:', error);
      }
    };
    loadSavedCredentials();
  }, []);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert("Error", "Please enter both email and password");
      return;
    }

    setIsLoading(true);
    try {
      await auth.signInWithEmailAndPassword(email, password);
      // Save credentials to AsyncStorage after successful login
      await AsyncStorage.multiSet([
        ['lastEmail', email],
        ['lastPassword', password]
      ]);
    } catch (error) {
      Alert.alert("Login Failed", error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        style={{ borderWidth: 1, marginBottom: 10, padding: 10 }}
        autoCapitalize="none"
        keyboardType="email-address"
        autoComplete="email"
      />
      <TextInput
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={{ borderWidth: 1, marginBottom: 10, padding: 10 }}
        autoComplete="password"
      />
      <Button 
        title={isLoading ? "Logging in..." : "Login"} 
        onPress={handleLogin} 
        disabled={isLoading}
      />
      <Button 
        title="Go to Register" 
        onPress={() => navigation.navigate("Register")} 
        color="gray"
      />
    </View>
  );
}

// Register Screen Component
function RegisterScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleRegister = async () => {
    if (!username.trim()) {
      Alert.alert("Error", "Username cannot be empty");
      return;
    }
    if (!email.trim() || !password.trim()) {
      Alert.alert("Error", "Please enter both email and password");
      return;
    }

    setIsLoading(true);
    try {
      const userCredential = await auth.createUserWithEmailAndPassword(email, password);
      const user = userCredential.user;
      
      await db.collection("users").doc(user.uid).set({
        username,
        email,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });
      
      // Save credentials to AsyncStorage after successful registration
      await AsyncStorage.multiSet([
        ['lastEmail', email],
        ['lastPassword', password]
      ]);
    } catch (error) {
      Alert.alert("Registration Failed", error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
        style={{ borderWidth: 1, marginBottom: 10, padding: 10 }}
        autoCapitalize="words"
      />
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        style={{ borderWidth: 1, marginBottom: 10, padding: 10 }}
        autoCapitalize="none"
        keyboardType="email-address"
        autoComplete="email"
      />
      <TextInput
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={{ borderWidth: 1, marginBottom: 10, padding: 10 }}
        autoComplete="password"
      />
      <Button 
        title={isLoading ? "Registering..." : "Register"} 
        onPress={handleRegister} 
        disabled={isLoading}
      />
      <Button 
        title="Back to Login" 
        onPress={() => navigation.goBack()} 
        color="gray"
      />
    </View>
  );
}

// Home Screen Component
function HomeScreen({ user, onLogout, username }) {
  return (
    <View style={[styles.recipeCard, { 
      flex: 1, 
      backgroundColor: '#FFF8F0',
      padding: 20,
      justifyContent: 'space-between'
    }]}>
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text style={[styles.recipeTitle, { 
          fontSize: 28,
          marginBottom: 10,
          textAlign: 'center',
          color: '#2E4057'
        }]}>
          Welcome back, {username || 'Chef'}!
        </Text>
        <Text style={[styles.sectionTitle, { 
          fontSize: 22,
          marginBottom: 20,
          fontStyle: 'italic',
          color: '#5A7D7C'
        }]}>
          Your personal kitchen companion
        </Text>
        <Text style={[styles.descriptionText, { 
          fontSize: 18,
          textAlign: 'center',
          lineHeight: 26,
          paddingHorizontal: 20
        }]}>
          Organize, create, and savor your favorite recipes all in one place
        </Text>
      </View>
      
      <TouchableOpacity 
        style={{
          backgroundColor: '#FF6B6B',
          paddingVertical: 12,
          paddingHorizontal: 30,
          borderRadius: 25,
          alignSelf: 'center',
          marginBottom: 30,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.2,
          shadowRadius: 4,
          elevation: 3,
        }} 
        onPress={() => {
          Alert.alert(
            "Confirm Logout",
            "Are you sure you want to logout?",
            [
              {
                text: "Cancel",
                style: "cancel"
              },
              {
                text: "Logout",
                style: "destructive",
                onPress: onLogout
              }
            ]
          );
        }}  
      >
        <Text style={{ 
          color: 'white', 
          fontWeight: 'bold', 
          fontSize: 16 
        }}>
          Logout
        </Text>
      </TouchableOpacity>
    </View>
  );
}

// Add Recipe Screen Component
function AddRecipeScreen({ navigation }) {
  const [recipe, setRecipe] = useState({
    title: "",
    description: "",
    prepTime: "",
    cookTime: "",
    servings: "",
    ingredients: [""],
    instructions: [""],
    difficulty: "Easy",
    category: "Main Course",
    imageUri: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Prevent going back if there are unsaved changes
  useEffect(() => {
    const unsubscribe = navigation.addListener('beforeRemove', (e) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        Alert.alert(
          "Unsaved changes",
          "You have unsaved changes. Are you sure you want to leave?",
          [
            { text: "Cancel", style: "cancel" },
            { 
              text: "Leave", 
              style: "destructive", 
              onPress: () => navigation.dispatch(e.data.action) 
            }
          ]
        );
      }
    });

    return unsubscribe;
  }, [hasUnsavedChanges, navigation]);

  // Check for unsaved changes
  useEffect(() => {
    const defaultRecipe = {
      title: "",
      description: "",
      prepTime: "",
      cookTime: "",
      servings: "",
      ingredients: [""],
      instructions: [""],
      difficulty: "Easy",
      category: "Main Course",
      imageUri: ""
    };
    setHasUnsavedChanges(JSON.stringify(recipe) !== JSON.stringify(defaultRecipe));
  }, [recipe]);

  const handleAddIngredient = () => {
    setRecipe({...recipe, ingredients: [...recipe.ingredients, ""]});
  };

  const handleRemoveIngredient = (index) => {
    if (recipe.ingredients.length > 1) {
      const newIngredients = [...recipe.ingredients];
      newIngredients.splice(index, 1);
      setRecipe({...recipe, ingredients: newIngredients});
    }
  };

  const handleIngredientChange = (text, index) => {
    const newIngredients = [...recipe.ingredients];
    newIngredients[index] = text;
    setRecipe({...recipe, ingredients: newIngredients});
  };

  const handleAddInstruction = () => {
    setRecipe({...recipe, instructions: [...recipe.instructions, ""]});
  };

  const handleRemoveInstruction = (index) => {
    if (recipe.instructions.length > 1) {
      const newInstructions = [...recipe.instructions];
      newInstructions.splice(index, 1);
      setRecipe({...recipe, instructions: newInstructions});
    }
  };

  const handleInstructionChange = (text, index) => {
    const newInstructions = [...recipe.instructions];
    newInstructions[index] = text;
    setRecipe({...recipe, instructions: newInstructions});
  };

  const handleAddRecipe = async () => {
    if (!recipe.title.trim()) {
      Alert.alert("Error", "Recipe title cannot be empty");
      return;
    }

    setIsSubmitting(true);
    try {
      // Add the current user's UID to the recipe
      const user = auth.currentUser;
      const recipeData = {
        ...recipe,
        userId: user.uid,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      };
      
      await db.collection("recipes").add(recipeData);
      Alert.alert("Success", "Recipe saved successfully!");
      // Reset form
      setRecipe({
        title: "",
        description: "",
        prepTime: "",
        cookTime: "",
        servings: "",
        ingredients: [""],
        instructions: [""],
        difficulty: "Easy",
        category: "Main Course",
        imageUri: ""
      });
      setHasUnsavedChanges(false);
    } catch (error) {
      Alert.alert("Error", error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <View style={[styles.recipeCard, { 
      flex: 1, 
      padding: 0,
      backgroundColor: '#F8F9FA',
      marginBottom: 0 
    }]}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        {/* Header */}
        <Text style={[styles.recipeTitle, { 
          fontSize: 28, 
          marginBottom: 25,
          color: '#2D3436'
        }]}>
          Create New Recipe
        </Text>
        
        {/* Recipe Title */}
        <Text style={[styles.sectionTitle, { marginBottom: 8 }]}>Recipe Title</Text>
        <TextInput
          placeholder="Enter recipe title"
          placeholderTextColor="#999"
          value={recipe.title}
          onChangeText={(text) => setRecipe({...recipe, title: text})}
          style={[styles.input, { 
            backgroundColor: '#FFFFFF',
            borderWidth: 1,
            borderColor: '#DFE6E9',
            borderRadius: 12,
            padding: 15,
            marginBottom: 20
          }]}
        />
        
        {/* Recipe Description */}
        <Text style={[styles.sectionTitle, { marginBottom: 8 }]}>Description</Text>
        <TextInput
          placeholder="Brief description about the recipe"
          placeholderTextColor="#999"
          value={recipe.description}
          onChangeText={(text) => setRecipe({...recipe, description: text})}
          multiline
          style={[styles.input, { 
            backgroundColor: '#FFFFFF',
            borderWidth: 1,
            borderColor: '#DFE6E9',
            borderRadius: 12,
            padding: 15,
            height: 100,
            textAlignVertical: 'top',
            marginBottom: 20
          }]}
        />
        
        {/* Cooking Details */}
        <View style={[styles.detailsContainer, { marginBottom: 20 }]}>
          {/* Prep Time */}
          <View style={styles.detailItem}>
            <Text style={[styles.detailLabel, { marginBottom: 8 }]}>Prep Time (mins)</Text>
            <TextInput
              placeholder="10"
              placeholderTextColor="#999"
              value={recipe.prepTime}
              onChangeText={(text) => setRecipe({...recipe, prepTime: text})}
              keyboardType="numeric"
              style={[styles.input, { 
                backgroundColor: '#FFFFFF',
                borderWidth: 1,
                borderColor: '#DFE6E9',
                borderRadius: 12,
                padding: 15,
                marginBottom: 0
              }]}
            />
          </View>

          {/* Cook Time */}
          <View style={styles.detailItem}>
            <Text style={[styles.detailLabel, { marginBottom: 8 }]}>Cook Time (mins)</Text>
            <TextInput
              placeholder="30"
              placeholderTextColor="#999"
              value={recipe.cookTime}
              onChangeText={(text) => setRecipe({...recipe, cookTime: text})}
              keyboardType="numeric"
              style={[styles.input, { 
                backgroundColor: '#FFFFFF',
                borderWidth: 1,
                borderColor: '#DFE6E9',
                borderRadius: 12,
                padding: 15,
                marginBottom: 0
              }]}
            />
          </View>
        </View>
        
        {/* Difficulty and Category */}
        <View style={[styles.detailsContainer, { marginBottom: 20 }]}>
          <View style={styles.detailItem}>
            <Text style={[styles.detailLabel, { marginBottom: 8 }]}>Difficulty</Text>
            <View style={{ 
              borderWidth: 1,
              borderColor: '#DFE6E9',
              borderRadius: 12,
              overflow: 'hidden'
            }}>
              <Picker
                selectedValue={recipe.difficulty}
                onValueChange={(itemValue) => setRecipe({...recipe, difficulty: itemValue})}
                style={{ backgroundColor: '#FFFFFF' }}
              >
                <Picker.Item label="Easy" value="Easy" />
                <Picker.Item label="Medium" value="Medium" />
                <Picker.Item label="Hard" value="Hard" />
              </Picker>
            </View>
          </View>
          <View style={styles.detailItem}>
            <Text style={[styles.detailLabel, { marginBottom: 8 }]}>Category</Text>
            <View style={{ 
              borderWidth: 1,
              borderColor: '#DFE6E9',
              borderRadius: 12,
              overflow: 'hidden'
            }}>
              <Picker
                selectedValue={recipe.category}
                onValueChange={(itemValue) => setRecipe({...recipe, category: itemValue})}
                style={{ backgroundColor: '#FFFFFF' }}
              >
                <Picker.Item label="Main Course" value="Main Course" />
                <Picker.Item label="Appetizer" value="Appetizer" />
                <Picker.Item label="Dessert" value="Dessert" />
                <Picker.Item label="Breakfast" value="Breakfast" />
                <Picker.Item label="Salad" value="Salad" />
                <Picker.Item label="Soup" value="Soup" />
                <Picker.Item label="Drink" value="Drink" />
              </Picker>
            </View>
          </View>
        </View>
        
        {/* Ingredients */}
        <View style={{ marginBottom: 20 }}>
          <View style={{ 
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: 15
          }}>
            <Text style={[styles.sectionTitle, { marginBottom: 0 }]}>Ingredients</Text>
            <TouchableOpacity 
              style={{ 
                backgroundColor: '#6B4EFF',
                paddingVertical: 8,
                paddingHorizontal: 15,
                borderRadius: 20
              }}
              onPress={handleAddIngredient}
            >
              <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>+ Add</Text>
            </TouchableOpacity>
          </View>
          
          {recipe.ingredients.map((ingredient, index) => (
            <View key={index} style={{ 
              flexDirection: 'row', 
              alignItems: 'center',
              marginBottom: 12
            }}>
              <TextInput
                placeholder={`Ingredient ${index + 1}`}
                placeholderTextColor="#999"
                value={ingredient}
                onChangeText={(text) => handleIngredientChange(text, index)}
                style={[styles.input, { 
                  flex: 1,
                  backgroundColor: '#FFFFFF',
                  borderWidth: 1,
                  borderColor: '#DFE6E9',
                  borderRadius: 12,
                  padding: 15,
                  marginRight: 10,
                  marginBottom: 0
                }]}
              />
              {recipe.ingredients.length > 1 && (
                <TouchableOpacity 
                  style={{ 
                    backgroundColor: '#FF7675',
                    width: 40,
                    height: 40,
                    borderRadius: 20,
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}
                  onPress={() => handleRemoveIngredient(index)}
                >
                  <Text style={{ color: '#FFFFFF', fontSize: 20 }}>−</Text>
                </TouchableOpacity>
              )}
            </View>
          ))}
        </View>
        
        {/* Instructions */}
        <View style={{ marginBottom: 20 }}>
          <View style={{ 
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: 15
          }}>
            <Text style={[styles.sectionTitle, { marginBottom: 0 }]}>Instructions</Text>
            <TouchableOpacity 
              style={{ 
                backgroundColor: '#6B4EFF',
                paddingVertical: 8,
                paddingHorizontal: 15,
                borderRadius: 20
              }}
              onPress={handleAddInstruction}
            >
              <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>+ Add Step</Text>
            </TouchableOpacity>
          </View>
          
          {recipe.instructions.map((instruction, index) => (
            <View key={index} style={{ marginBottom: 15 }}>
              <Text style={{ 
                fontSize: 16,
                fontWeight: '600',
                color: '#6B4EFF',
                marginBottom: 8
              }}>
                Step {index + 1}
              </Text>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <TextInput
                  placeholder={`Describe step ${index + 1}`}
                  placeholderTextColor="#999"
                  value={instruction}
                  onChangeText={(text) => handleInstructionChange(text, index)}
                  multiline
                  style={[styles.input, { 
                    flex: 1,
                    backgroundColor: '#FFFFFF',
                    borderWidth: 1,
                    borderColor: '#DFE6E9',
                    borderRadius: 12,
                    padding: 15,
                    height: 100,
                    textAlignVertical: 'top',
                    marginRight: 10,
                    marginBottom: 0
                  }]}
                />
                {recipe.instructions.length > 1 && (
                  <TouchableOpacity 
                    style={{ 
                      backgroundColor: '#FF7675',
                      width: 40,
                      height: 40,
                      borderRadius: 20,
                      justifyContent: 'center',
                      alignItems: 'center'
                    }}
                    onPress={() => handleRemoveInstruction(index)}
                  >
                    <Text style={{ color: '#FFFFFF', fontSize: 20 }}>−</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ))}
        </View>
        
        {/* Save Button */}
        <TouchableOpacity 
          style={{ 
            backgroundColor: '#6B4EFF',
            padding: 18,
            borderRadius: 12,
            alignItems: 'center',
            marginTop: 20,
            opacity: isSubmitting ? 0.7 : 1
          }}
          onPress={handleAddRecipe}
          disabled={isSubmitting}
        >
          <Text style={{ 
            color: '#FFFFFF',
            fontSize: 18,
            fontWeight: '600'
          }}>
            {isSubmitting ? "Saving..." : "Save Recipe"}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

// Edit Recipe Screen Component
function EditRecipeScreen({ navigation, route }) {
  const { recipeId } = route.params;
  const [recipe, setRecipe] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Prevent going back if there are unsaved changes
  useEffect(() => {
    const unsubscribe = navigation.addListener('beforeRemove', (e) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        Alert.alert(
          "Unsaved changes",
          "You have unsaved changes. Are you sure you want to leave?",
          [
            { text: "Cancel", style: "cancel" },
            { 
              text: "Leave", 
              style: "destructive", 
              onPress: () => navigation.dispatch(e.data.action) 
            }
          ]
        );
      }
    });

    return unsubscribe;
  }, [hasUnsavedChanges, navigation]);

  // Fetch the recipe data when the component mounts
  useEffect(() => {
    const fetchRecipe = async () => {
      try {
        const doc = await db.collection("recipes").doc(recipeId).get();
        if (doc.exists) {
          setRecipe({
            id: doc.id,
            ...doc.data()
          });
        } else {
          Alert.alert("Error", "Recipe not found");
          navigation.goBack();
        }
      } catch (error) {
        Alert.alert("Error", error.message);
        navigation.goBack();
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchRecipe();
  }, [recipeId, navigation]);

  // Check for unsaved changes
  useEffect(() => {
    if (!recipe) return;
    
    const checkChanges = async () => {
      try {
        const doc = await db.collection("recipes").doc(recipeId).get();
        if (doc.exists) {
          const originalRecipe = doc.data();
          setHasUnsavedChanges(JSON.stringify(recipe) !== JSON.stringify(originalRecipe));
        }
      } catch (error) {
        console.error("Error checking changes:", error);
      }
    };
    
    checkChanges();
  }, [recipe, recipeId]);

  // ... rest of the component remains the same ...


  const handleAddIngredient = () => {
    setRecipe({...recipe, ingredients: [...recipe.ingredients, ""]});
  };

  const handleRemoveIngredient = (index) => {
    if (recipe.ingredients.length > 1) {
      const newIngredients = [...recipe.ingredients];
      newIngredients.splice(index, 1);
      setRecipe({...recipe, ingredients: newIngredients});
    }
  };

  const handleIngredientChange = (text, index) => {
    const newIngredients = [...recipe.ingredients];
    newIngredients[index] = text;
    setRecipe({...recipe, ingredients: newIngredients});
  };

  const handleAddInstruction = () => {
    setRecipe({...recipe, instructions: [...recipe.instructions, ""]});
  };

  const handleRemoveInstruction = (index) => {
    if (recipe.instructions.length > 1) {
      const newInstructions = [...recipe.instructions];
      newInstructions.splice(index, 1);
      setRecipe({...recipe, instructions: newInstructions});
    }
  };

  const handleInstructionChange = (text, index) => {
    const newInstructions = [...recipe.instructions];
    newInstructions[index] = text;
    setRecipe({...recipe, instructions: newInstructions});
  };

  const handleUpdateRecipe = async () => {
    if (!recipe.title.trim()) {
      Alert.alert("Error", "Recipe title cannot be empty");
      return;
    }

    setIsSubmitting(true);
    try {
      // Update the recipe in Firestore
      await db.collection("recipes").doc(recipe.id).update({
        ...recipe,
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      });
      
      Alert.alert("Success", "Recipe updated successfully!");
      setHasUnsavedChanges(false);
      navigation.goBack();
    } catch (error) {
      Alert.alert("Error", error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading || !recipe) {
    return (
      <View style={{ 
        flex: 1, 
        justifyContent: "center", 
        alignItems: "center",
        backgroundColor: '#F8F9FA'
      }}>
        <ActivityIndicator size="large" color="#6B4EFF" />
      </View>
    );
  }

  return (
    <View style={[styles.recipeCard, { 
      flex: 1, 
      padding: 0,
      backgroundColor: '#F8F9FA',
      marginBottom: 0 
    }]}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        {/* Header with back button */}
        <View style={{ 
          flexDirection: 'row', 
          alignItems: 'center', 
          marginBottom: 25 
        }}>
          <TouchableOpacity 
            onPress={() => {
              if (hasUnsavedChanges) {
                Alert.alert(
                  "Unsaved changes",
                  "You have unsaved changes. Are you sure you want to leave?",
                  [
                    { text: "Cancel", style: "cancel" },
                    { 
                      text: "Leave", 
                      style: "destructive", 
                      onPress: () => navigation.goBack() 
                    }
                  ]
                );
              } else {
                navigation.goBack();
              }
            }}
            style={{ 
              marginRight: 15,
              backgroundColor: '#E9ECEF',
              width: 40,
              height: 40,
              borderRadius: 20,
              justifyContent: 'center',
              alignItems: 'center'
            }}
          >
            <Text style={{ fontSize: 20, color: '#495057' }}>←</Text>
          </TouchableOpacity>
          <Text style={[styles.recipeTitle, { 
            fontSize: 28, 
            marginBottom: 0,
            color: '#2D3436'
          }]}>
            Edit Recipe
          </Text>
        </View>
        
        {/* Recipe Title */}
        <Text style={[styles.sectionTitle, { marginBottom: 8 }]}>Recipe Title</Text>
        <TextInput
          placeholder="Enter recipe title"
          placeholderTextColor="#999"
          value={recipe.title}
          onChangeText={(text) => setRecipe({...recipe, title: text})}
          style={[styles.input, { 
            backgroundColor: '#FFFFFF',
            borderWidth: 1,
            borderColor: '#DFE6E9',
            borderRadius: 12,
            padding: 15,
            marginBottom: 20
          }]}
        />
        
        {/* Recipe Description */}
        <Text style={[styles.sectionTitle, { marginBottom: 8 }]}>Description</Text>
        <TextInput
          placeholder="Brief description about the recipe"
          placeholderTextColor="#999"
          value={recipe.description}
          onChangeText={(text) => setRecipe({...recipe, description: text})}
          multiline
          style={[styles.input, { 
            backgroundColor: '#FFFFFF',
            borderWidth: 1,
            borderColor: '#DFE6E9',
            borderRadius: 12,
            padding: 15,
            height: 100,
            textAlignVertical: 'top',
            marginBottom: 20
          }]}
        />
        
        {/* Cooking Details */}
        <View style={[styles.detailsContainer, { marginBottom: 20 }]}>
          {/* Prep Time */}
          <View style={styles.detailItem}>
            <Text style={[styles.detailLabel, { marginBottom: 8 }]}>Prep Time (mins)</Text>
            <TextInput
              placeholder="10"
              placeholderTextColor="#999"
              value={recipe.prepTime}
              onChangeText={(text) => setRecipe({...recipe, prepTime: text})}
              keyboardType="numeric"
              style={[styles.input, { 
                backgroundColor: '#FFFFFF',
                borderWidth: 1,
                borderColor: '#DFE6E9',
                borderRadius: 12,
                padding: 15,
                marginBottom: 0
              }]}
            />
          </View>

          {/* Cook Time */}
          <View style={styles.detailItem}>
            <Text style={[styles.detailLabel, { marginBottom: 8 }]}>Cook Time (mins)</Text>
            <TextInput
              placeholder="30"
              placeholderTextColor="#999"
              value={recipe.cookTime}
              onChangeText={(text) => setRecipe({...recipe, cookTime: text})}
              keyboardType="numeric"
              style={[styles.input, { 
                backgroundColor: '#FFFFFF',
                borderWidth: 1,
                borderColor: '#DFE6E9',
                borderRadius: 12,
                padding: 15,
                marginBottom: 0
              }]}
            />
          </View>
        </View>
        
        {/* Difficulty and Category */}
        <View style={[styles.detailsContainer, { marginBottom: 20 }]}>
          <View style={styles.detailItem}>
            <Text style={[styles.detailLabel, { marginBottom: 8 }]}>Difficulty</Text>
            <View style={{ 
              borderWidth: 1,
              borderColor: '#DFE6E9',
              borderRadius: 12,
              overflow: 'hidden'
            }}>
              <Picker
                selectedValue={recipe.difficulty}
                onValueChange={(itemValue) => setRecipe({...recipe, difficulty: itemValue})}
                style={{ backgroundColor: '#FFFFFF' }}
              >
                <Picker.Item label="Easy" value="Easy" />
                <Picker.Item label="Medium" value="Medium" />
                <Picker.Item label="Hard" value="Hard" />
              </Picker>
            </View>
          </View>
          <View style={styles.detailItem}>
            <Text style={[styles.detailLabel, { marginBottom: 8 }]}>Category</Text>
            <View style={{ 
              borderWidth: 1,
              borderColor: '#DFE6E9',
              borderRadius: 12,
              overflow: 'hidden'
            }}>
              <Picker
                selectedValue={recipe.category}
                onValueChange={(itemValue) => setRecipe({...recipe, category: itemValue})}
                style={{ backgroundColor: '#FFFFFF' }}
              >
                <Picker.Item label="Main Course" value="Main Course" />
                <Picker.Item label="Appetizer" value="Appetizer" />
                <Picker.Item label="Dessert" value="Dessert" />
                <Picker.Item label="Breakfast" value="Breakfast" />
                <Picker.Item label="Salad" value="Salad" />
                <Picker.Item label="Soup" value="Soup" />
                <Picker.Item label="Drink" value="Drink" />
              </Picker>
            </View>
          </View>
        </View>
        
        {/* Ingredients */}
        <View style={{ marginBottom: 20 }}>
          <View style={{ 
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: 15
          }}>
            <Text style={[styles.sectionTitle, { marginBottom: 0 }]}>Ingredients</Text>
            <TouchableOpacity 
              style={{ 
                backgroundColor: '#6B4EFF',
                paddingVertical: 8,
                paddingHorizontal: 15,
                borderRadius: 20
              }}
              onPress={handleAddIngredient}
            >
              <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>+ Add</Text>
            </TouchableOpacity>
          </View>
          
          {recipe.ingredients.map((ingredient, index) => (
            <View key={index} style={{ 
              flexDirection: 'row', 
              alignItems: 'center',
              marginBottom: 12
            }}>
              <TextInput
                placeholder={`Ingredient ${index + 1}`}
                placeholderTextColor="#999"
                value={ingredient}
                onChangeText={(text) => handleIngredientChange(text, index)}
                style={[styles.input, { 
                  flex: 1,
                  backgroundColor: '#FFFFFF',
                  borderWidth: 1,
                  borderColor: '#DFE6E9',
                  borderRadius: 12,
                  padding: 15,
                  marginRight: 10,
                  marginBottom: 0
                }]}
              />
              {recipe.ingredients.length > 1 && (
                <TouchableOpacity 
                  style={{ 
                    backgroundColor: '#FF7675',
                    width: 40,
                    height: 40,
                    borderRadius: 20,
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}
                  onPress={() => handleRemoveIngredient(index)}
                >
                  <Text style={{ color: '#FFFFFF', fontSize: 20 }}>−</Text>
                </TouchableOpacity>
              )}
            </View>
          ))}
        </View>
        
        {/* Instructions */}
        <View style={{ marginBottom: 20 }}>
          <View style={{ 
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: 15
          }}>
            <Text style={[styles.sectionTitle, { marginBottom: 0 }]}>Instructions</Text>
            <TouchableOpacity 
              style={{ 
                backgroundColor: '#6B4EFF',
                paddingVertical: 8,
                paddingHorizontal: 15,
                borderRadius: 20
              }}
              onPress={handleAddInstruction}
            >
              <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>+ Add Step</Text>
            </TouchableOpacity>
          </View>
          
          {recipe.instructions.map((instruction, index) => (
            <View key={index} style={{ marginBottom: 15 }}>
              <Text style={{ 
                fontSize: 16,
                fontWeight: '600',
                color: '#6B4EFF',
                marginBottom: 8
              }}>
                Step {index + 1}
              </Text>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <TextInput
                  placeholder={`Describe step ${index + 1}`}
                  placeholderTextColor="#999"
                  value={instruction}
                  onChangeText={(text) => handleInstructionChange(text, index)}
                  multiline
                  style={[styles.input, { 
                    flex: 1,
                    backgroundColor: '#FFFFFF',
                    borderWidth: 1,
                    borderColor: '#DFE6E9',
                    borderRadius: 12,
                    padding: 15,
                    height: 100,
                    textAlignVertical: 'top',
                    marginRight: 10,
                    marginBottom: 0
                  }]}
                />
                {recipe.instructions.length > 1 && (
                  <TouchableOpacity 
                    style={{ 
                      backgroundColor: '#FF7675',
                      width: 40,
                      height: 40,
                      borderRadius: 20,
                      justifyContent: 'center',
                      alignItems: 'center'
                    }}
                    onPress={() => handleRemoveInstruction(index)}
                  >
                    <Text style={{ color: '#FFFFFF', fontSize: 20 }}>−</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ))}
        </View>
        
        {/* Update Button */}
        <TouchableOpacity 
          style={{ 
            backgroundColor: '#6B4EFF',
            padding: 18,
            borderRadius: 12,
            alignItems: 'center',
            marginTop: 20,
            opacity: isSubmitting ? 0.7 : 1
          }}
          onPress={handleUpdateRecipe}
          disabled={isSubmitting}
        >
          <Text style={{ 
            color: '#FFFFFF',
            fontSize: 18,
            fontWeight: '600'
          }}>
            {isSubmitting ? "Updating..." : "Update Recipe"}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

// My Recipes Screen Component
function MyRecipesScreen({ navigation }) {
  const [recipes, setRecipes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchRecipes = async () => {
    try {
      const user = auth.currentUser;
      const querySnapshot = await db.collection("recipes")
        .where("userId", "==", user.uid)
        .orderBy("createdAt", "desc")
        .get();
      
      const recipesList = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setRecipes(recipesList);
    } catch (error) {
      Alert.alert("Error", error.message);
    } finally {
      setIsLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchRecipes();
  };

  useEffect(() => {
    fetchRecipes();
  }, []);

  const renderRecipeItem = ({ item }) => (
    <View style={styles.recipeCard}>
      <Text style={styles.recipeTitle}>{item.title}</Text>
      
      {item.description && (
        <>
          <Text style={styles.sectionTitle}>Description</Text>
          <Text style={styles.descriptionText}>{item.description}</Text>
        </>
      )}
      
      <View style={styles.detailsContainer}>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Prep Time</Text>
          <Text style={styles.detailValue}>{item.prepTime} mins</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Cook Time</Text>
          <Text style={styles.detailValue}>{item.cookTime} mins</Text>
        </View>
      </View>
      
      <View style={styles.detailsContainer}>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Difficulty</Text>
          <Text style={styles.detailValue}>{item.difficulty}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Category</Text>
          <Text style={styles.detailValue}>{item.category}</Text>
        </View>
      </View>
      
      <Text style={styles.sectionTitle}>Ingredients</Text>
      {item.ingredients.map((ingredient, index) => (
        <View key={index} style={styles.ingredientItem}>
          <Text style={styles.bulletPoint}>•</Text>
          <Text style={styles.ingredientText}>{ingredient}</Text>
        </View>
      ))}
      
      <Text style={styles.sectionTitle}>Instructions</Text>
      {item.instructions.map((instruction, index) => (
        <View key={index} style={styles.instructionItem}>
          <Text style={styles.stepNumber}>{index + 1}.</Text>
          <Text style={styles.instructionText}>{instruction}</Text>
        </View>
      ))}
      
      <TouchableOpacity
        style={{
          backgroundColor: '#6B4EFF',
          padding: 12,
          borderRadius: 8,
          marginTop: 15,
          alignItems: 'center'
        }}
        onPress={() => navigation.navigate('EditRecipe', { recipeId: item.id })}
      >
        <Text style={{ 
          color: 'white', 
          fontWeight: '600',
          fontSize: 16
        }}>
          Edit Recipe
        </Text>
      </TouchableOpacity>
    </View>
  );

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <FlatList
      data={recipes}
      keyExtractor={(item) => item.id}
      renderItem={renderRecipeItem}
      refreshing={refreshing}
      onRefresh={handleRefresh}
      contentContainerStyle={styles.listContainer}
      ListEmptyComponent={
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No recipes found. Add your first recipe!</Text>
        </View>
      }
    />
  );
}

// Styles
const styles = {
  // Main container styles
  listContainer: {
    padding: 20,
    backgroundColor: '#F9F7F5', // Soft warm background
  },

  // Recipe card - now with more elegance
  recipeCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16, // More rounded corners
    padding: 20,
    marginBottom: 20,
    shadowColor: '#3D3B40',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 5,
    borderWidth: 1,
    borderColor: '#F0F0F0', // Subtle border
  },

  // Typography styles
  recipeTitle: {
    fontSize: 24,
    fontWeight: '700', // Semi-bold
    marginBottom: 12,
    color: '#2E3440', // Dark blue-gray
    fontFamily: 'System', // Will use San Francisco on iOS, Roboto on Android
    letterSpacing: 0.3,
  },

  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginTop: 18,
    marginBottom: 12,
    color: '#4C566A', // Medium blue-gray
    fontFamily: 'System',
    letterSpacing: 0.2,
  },

  descriptionText: {
    fontSize: 17,
    color: '#4C566A',
    marginBottom: 16,
    lineHeight: 24, // Better readability
    fontFamily: 'System',
  },

  // Layout components
  detailsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    backgroundColor: '#F8F9FA', // Light gray background
    borderRadius: 12,
    padding: 12,
  },

  detailItem: {
    flex: 1,
    paddingHorizontal: 8,
  },

  detailLabel: {
    fontSize: 15,
    color: '#5E81AC', // Nice blue
    fontWeight: '500',
    marginBottom: 4,
    fontFamily: 'System',
  },
  
  input: {
    fontSize: 16,
    color: '#2D3436',
    fontFamily: 'System',
  },

  detailValue: {
    fontSize: 17,
    fontWeight: '600',
    color: '#434C5E',
    fontFamily: 'System',
  },

  // List items
  ingredientItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
    paddingVertical: 6,
  },

  bulletPoint: {
    marginRight: 12,
    fontSize: 18,
    color: '#5E81AC', // Matching blue
    marginTop: 2,
  },

  ingredientText: {
    fontSize: 17,
    flex: 1,
    color: '#4C566A',
    lineHeight: 24,
    fontFamily: 'System',
  },

  instructionItem: {
    flexDirection: 'row',
    marginBottom: 16,
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 12,
  },

  stepNumber: {
    fontWeight: '700',
    marginRight: 12,
    color: '#5E81AC',
    fontSize: 16,
    minWidth: 24,
    textAlign: 'center',
    marginTop: 2,
  },

  instructionText: {
    fontSize: 17,
    flex: 1,
    color: '#4C566A',
    lineHeight: 24,
    fontFamily: 'System',
  },

  // Empty state
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 60,
    padding: 30,
  },

  emptyText: {
    fontSize: 20,
    color: '#81A1C1', // Lighter blue
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 28,
    fontFamily: 'System',
  },

  // Additional decorative elements
  decorativeDivider: {
    height: 1,
    backgroundColor: '#E5E9F0',
    marginVertical: 16,
  },
};

// Main Tab Navigator
function MainTabs({ user, onLogout, username }) {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: "blue",
        tabBarInactiveTintColor: "gray",
        tabBarLabelStyle: { fontSize: 12 },
      }}
    >
      <Tab.Screen name="Home">
        {(props) => <HomeScreen {...props} user={user} onLogout={onLogout} username={username} />}
      </Tab.Screen>
      <Tab.Screen name="AddRecipe" component={AddRecipeScreen} options={{ title: "Add Recipe" }} />
      <Tab.Screen name="MyRecipes" component={MyRecipesScreen} options={{ title: "My Recipes" }} />
    </Tab.Navigator>
  );
}

// Main App Component
export default function App() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [username, setUsername] = useState("");

  // Fetch user data including username when auth state changes
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        try {
          // Fetch user document from Firestore
          const userDoc = await db.collection("users").doc(currentUser.uid).get();
          if (userDoc.exists) {
            setUsername(userDoc.data().username);
          }
        } catch (error) {
          console.error("Error fetching user data:", error);
        }
      } else {
        // Clear saved password when user logs out (for security)
        try {
          await AsyncStorage.removeItem('lastPassword');
        } catch (error) {
          console.error("Error clearing saved password:", error);
        }
      }
      
      setIsLoading(false);
    });
    return unsubscribe;
  }, []);

  const handleLogout = async () => {
    try {
      await auth.signOut();
      setUsername(""); // Clear username on logout
    } catch (error) {
      Alert.alert("Error", error.message);
    }
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: "#f8f8f8" },
          headerTitleStyle: { fontWeight: "bold" },
        }}
      >
        {user ? (
          <>
            <Stack.Screen name="Main" options={{ headerShown: false }}>
              {() => <MainTabs user={user} onLogout={handleLogout} username={username} />}
            </Stack.Screen>
            <Stack.Screen 
              name="EditRecipe" 
              component={EditRecipeScreen} 
              options={{ 
                title: "Edit Recipe",
                headerStyle: {
                  backgroundColor: '#6B4EFF',
                },
                headerTintColor: '#fff',
                headerTitleStyle: {
                  fontWeight: '600',
                },
              }} 
            />
          </>
        ) : (
          <>
            <Stack.Screen name="Login" component={LoginScreen} options={{ title: "Login" }} />
            <Stack.Screen name="Register" component={RegisterScreen} options={{ title: "Register" }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}